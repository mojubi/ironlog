# ◆ IRONLOG — Workout Tracker PWA

## Was ist das?
Eine Progressive Web App (PWA), die sich wie eine echte App auf deinem Handy installieren lässt — ohne App Store.

## Dateien
```
ironlog-pwa/
├── index.html      ← Die komplette App
├── manifest.json   ← PWA-Konfiguration
├── sw.js           ← Service Worker (Offline-Support)
├── icons/
│   ├── icon-192.png
│   └── icon-512.png
└── README.md       ← Diese Datei
```

## Installation auf dem Handy

### Option 1: Über GitHub Pages (empfohlen, kostenlos)

1. **GitHub Account erstellen** (falls noch nicht vorhanden): https://github.com
2. **Neues Repository erstellen**: Klicke auf "New Repository", nenne es z.B. `ironlog`
3. **Dateien hochladen**: Lade alle Dateien aus diesem Ordner hoch (index.html, manifest.json, sw.js, icons/)
4. **GitHub Pages aktivieren**: 
   - Gehe zu Settings → Pages
   - Source: "Deploy from a branch"
   - Branch: `main`, Ordner: `/ (root)`
   - Save
5. **Warte 1-2 Minuten**, dann ist deine App unter `https://DEIN-USERNAME.github.io/ironlog/` erreichbar
6. **Auf dem Handy öffnen** und installieren (siehe unten)

### Option 2: Über Netlify (noch einfacher)

1. Gehe zu https://app.netlify.com/drop
2. Ziehe den gesamten `ironlog-pwa` Ordner per Drag & Drop rein
3. Fertig! Du bekommst sofort eine URL

### Auf dem Handy installieren

**iPhone (Safari):**
- Öffne die URL in Safari
- Tippe auf das Teilen-Symbol (□↑)
- Wähle "Zum Home-Bildschirm"
- Fertig — IRONLOG erscheint als App-Icon!

**Android (Chrome):**
- Öffne die URL in Chrome
- Es erscheint automatisch ein Banner "Zum Startbildschirm hinzufügen"
- Falls nicht: Tippe auf ⋮ → "App installieren"

## Features
- ✅ Funktioniert offline
- ✅ Trainingsplan (PPL + Cardio) vorgeladen
- ✅ Übungen hinzufügen & entfernen
- ✅ Gewicht & Reps pro Set loggen
- ✅ Letzte Session als Referenz beim Training
- ✅ Fortschritte pro Übung (Charts)
- ✅ Personal Records
- ✅ Wöchentliches Volumen-Tracking
- ✅ Daten bleiben lokal gespeichert

## Hinweis
Deine Daten werden nur lokal auf deinem Gerät gespeichert (localStorage). 
Es werden keine Daten an Server gesendet. Wenn du den Browser-Cache löschst, 
gehen die Daten verloren — also am besten regelmäßig als installierte PWA nutzen.
